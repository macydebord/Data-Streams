import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DataStreams extends JFrame
{
    private JTextArea originalTextArea;
    private JTextArea filteredTextArea;
    private JTextField searchTextField;

    public DataStreams()
    {
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setUp();
    }

    private void setUp()
    {
        originalTextArea = new JTextArea();
        JScrollPane originalScrollPane = new JScrollPane(originalTextArea);

        filteredTextArea = new JTextArea();
        JScrollPane filteredScrollPane = new JScrollPane(filteredTextArea);

        JPanel textPanel = new JPanel(new GridLayout(1, 2));
        textPanel.add(originalScrollPane);
        textPanel.add(filteredScrollPane);
        add(textPanel, BorderLayout.CENTER);

        searchTextField = new JTextField(20);
        JButton loadButton = new JButton("Load File");
        loadButton.addActionListener(e -> loadFile());

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchFile());

        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(e -> System.exit(0));

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(new JLabel("Search String: "));
        buttonPanel.add(searchTextField);
        buttonPanel.add(loadButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(quitButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadFile()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Text files", "txt"));
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION)
        {
            Path filePath = fileChooser.getSelectedFile().toPath();
            try (Stream<String> lines = Files.lines(filePath))
            {
                List<String> content = lines.collect(Collectors.toList());
                originalTextArea.setText(String.join("\n", content));
            } catch (IOException e)
            {
                JOptionPane.showMessageDialog(this, "An error occurred while loading the file.", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    private void searchFile()
    {
        String searchString = searchTextField.getText().trim();
        if (searchString.isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Please enter a search string.");
            return;
        }

        String originalText = originalTextArea.getText();
        if (originalText.isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Please load a file first.");
            return;
        }

        List<String> filteredLines = Stream.of(originalText.split("\n"))
                .filter(line -> line.contains(searchString))
                .collect(Collectors.toList());

        filteredTextArea.setText(String.join("\n", filteredLines));
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(() -> new DataStreams().setVisible(true));
    }
}

